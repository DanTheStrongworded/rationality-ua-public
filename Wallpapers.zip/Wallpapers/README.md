# Change Your Mind

Безкоштовні шпалери на робочий стіл від Дениса Лук'яненка (@denlukia)

## Ліцензія

[Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/).

## Атрибуція

При використанні цих шпалер, будь ласка, вказуйте авторство: «Шпалери від Дениса Лук'яненка у пару до [українського перекладу](github.com/DanTheStrongworded/rationality-ua-public) книг "Rationality: A to Z", ліцензовано за CC BY 4.0».

Шпалери від Дениса Лук'яненка у пару до українського перекладу книг "Rationality: A to Z" (github.com/DanTheStrongworded/rationality-ua-public), ліцензовано за CC BY 4.0
